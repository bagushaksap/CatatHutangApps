package com.android.myapplication.ui.main

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.android.myapplication.R
import com.android.myapplication.helper.ViewModelFactory
import com.android.myapplication.preference.SettingPreferences
import com.android.myapplication.preference.SettingViewModel
import com.android.myapplication.preference.dataStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SpashActivity : AppCompatActivity() {

    private val pref by lazy { SettingPreferences.getInstance(application.dataStore) }
    private val vModel by lazy {
        ViewModelProvider(this, ViewModelFactory(application, pref))[SettingViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spash)

        lifecycleScope.launch {
            delay(2000)
            startActivity(Intent(this@SpashActivity, MainActivity::class.java))
            finish()
        }

        vModel.getThemeSettings().observe(this) { isDarkModeActive ->
            AppCompatDelegate.setDefaultNightMode(
                if (isDarkModeActive) AppCompatDelegate.MODE_NIGHT_YES
                else AppCompatDelegate.MODE_NIGHT_NO
            )
        }
    }
}