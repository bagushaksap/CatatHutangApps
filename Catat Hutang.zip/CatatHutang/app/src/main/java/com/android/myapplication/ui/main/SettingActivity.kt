package com.android.myapplication.ui.main

import android.content.Intent
import android.os.Bundle
import android.widget.CompoundButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import com.android.myapplication.R
import com.android.myapplication.helper.ViewModelFactory
import com.android.myapplication.preference.SettingPreferences
import com.android.myapplication.preference.SettingViewModel
import com.android.myapplication.preference.dataStore
import com.android.myapplication.util.MyService
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import kotlin.jvm.java

class SettingActivity : AppCompatActivity() {

    private val pref by lazy { SettingPreferences.getInstance(application.dataStore) }
    private val vModel by lazy {
        ViewModelProvider(this, ViewModelFactory(application, pref))[SettingViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_setting)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val switchTheme = findViewById<MaterialSwitch>(R.id.themeSwitch)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        val stopServiceButton = findViewById<MaterialButton>(R.id.stopServiceButton)

        stopServiceButton.setOnClickListener {
            val serviceIntent = Intent(this, MyService::class.java)
            stopService(serviceIntent)
        }

        toolbar.setNavigationOnClickListener { finish() }

        vModel.getThemeSettings().observe(this) { isDarkModeActive ->
            AppCompatDelegate.setDefaultNightMode(
                if (isDarkModeActive) AppCompatDelegate.MODE_NIGHT_YES
                else AppCompatDelegate.MODE_NIGHT_NO
            )
            switchTheme.isChecked = isDarkModeActive
        }

        switchTheme.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            vModel.saveThemeSetting(isChecked)
        }
    }
}