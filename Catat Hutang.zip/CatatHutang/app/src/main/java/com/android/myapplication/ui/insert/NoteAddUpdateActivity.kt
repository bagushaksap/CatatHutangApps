package com.android.myapplication.ui.insert

import android.os.Bundle
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.ViewGroupCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import com.android.myapplication.R
import com.android.myapplication.database.Note
import com.android.myapplication.databinding.ActivityNoteAddUpdateBinding
import com.android.myapplication.helper.ViewModelFactory

import com.google.android.material.dialog.MaterialAlertDialogBuilder
class NoteAddUpdateActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_NOTE = "extra_note"
        const val ALERT_DIALOG_CLOSE = 10
        const val ALERT_DIALOG_DELETE = 20
    }

    private var isEdit = false
    private var note: Note? = null

    private lateinit var noteAddUpdateViewModel: NoteAddUpdateViewModel

    private val binding: ActivityNoteAddUpdateBinding by lazy {
        ActivityNoteAddUpdateBinding.inflate(
            layoutInflater
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setFullScreen()

        noteAddUpdateViewModel = obtainViewModel(this@NoteAddUpdateActivity)

        note = intent.getParcelableExtra(EXTRA_NOTE)

        if (note != null) {
            isEdit = true
        } else {
            note = Note()
        }

        val actionBarTitle: String
        val btnTitle: String

        if (isEdit) {
            actionBarTitle = getString(R.string.change)
            btnTitle = getString(R.string.update)
            if (note != null) {
                note?.let { note ->
                    binding.edtTitle.setText(note.nama)
                    binding.edtDescription.setText(note.jumlah.toString())
                }
            }
        } else {
            actionBarTitle = getString(R.string.add)
            btnTitle = getString(R.string.save)
        }

        binding.toolbar.title = actionBarTitle
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.btnSubmit.text = btnTitle

        binding.btnSubmit.setOnClickListener {
            val nama = binding.edtTitle.text.toString().trim()
            val jumlah = binding.edtDescription.text.toString().trim()
            when {
                nama.isEmpty() -> {
                    binding.edtTitle.error = getString(R.string.empty)
                }

                jumlah.isEmpty() -> {
                    binding.edtDescription.error = getString(R.string.empty)
                }

                else -> {
                    note.let { note ->
                        note?.nama = nama
                        note?.jumlah = jumlah.toInt()
                    }
                    if (isEdit) {
                        noteAddUpdateViewModel.update(note as Note)
                        showToast(getString(R.string.changed))
                    } else {
                        noteAddUpdateViewModel.insert(note as Note)
                        showToast(getString(R.string.added))
                    }
                    finish()
                }
            }
        }

        binding.toolbar.setOnMenuItemClickListener { menu ->
            when (menu.itemId) {
                R.id.action_delete -> {
                    showAlertDialog(ALERT_DIALOG_DELETE)
                    true
                }
                else -> false
            }
        }

        binding.toolbar.setNavigationOnClickListener { showAlertDialog(ALERT_DIALOG_CLOSE) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                showAlertDialog(ALERT_DIALOG_CLOSE)
            }
        })
    }

    private fun showAlertDialog(type: Int) {
        val isDialogClose = type == ALERT_DIALOG_CLOSE
        val dialogTitle: String
        val dialogMessage: String
        if (isDialogClose) {
            dialogTitle = getString(R.string.cancel)
            dialogMessage = getString(R.string.message_cancel)
        } else {
            dialogMessage = getString(R.string.message_delete)
            dialogTitle = getString(R.string.delete)
        }
        MaterialAlertDialogBuilder(this).apply {
            setTitle(dialogTitle) // Set the title
            setMessage(dialogMessage) // Set the message
            setCancelable(false) // Prevent user from dismissing the dialog by clicking outside or pressing back
            setPositiveButton(getString(R.string.yes)) { dialog, _ -> // Set the positive button and its click listener
                if (!isDialogClose) { // Check if it's a close dialog or delete dialog
                    noteAddUpdateViewModel.delete(note as Note) // Perform the delete operation
                    showToast(getString(R.string.deleted)) // Show a toast message
                }
                finish() // Finish the activity
                dialog.dismiss()
            }
            setNegativeButton(getString(R.string.no)) { dialog, _ -> // Set the negative button and its click listener
                dialog.cancel() // Cancel the dialog
            }
        }.show() // Create and show the dialog
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun setFullScreen() {
        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun obtainViewModel(activity: AppCompatActivity): NoteAddUpdateViewModel {
        val factory = ViewModelFactory.getInstance(activity.application)
        return ViewModelProvider(activity, factory).get(NoteAddUpdateViewModel::class.java)
    }
}